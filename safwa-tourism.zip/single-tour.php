<?php
/**
 * Single Tour Template
 */

get_header();

while (have_posts()) : the_post();
    // Get tour meta data
    $regular_price = get_post_meta(get_the_ID(), '_tour_regular_price', true);
    $sale_price = get_post_meta(get_the_ID(), '_tour_sale_price', true);
    $duration = get_post_meta(get_the_ID(), '_tour_duration', true);
    $max_people = get_post_meta(get_the_ID(), '_tour_max_people', true);
    $min_age = get_post_meta(get_the_ID(), '_tour_min_age', true);
    $location = get_post_meta(get_the_ID(), '_tour_location', true);
    $tour_type = get_post_meta(get_the_ID(), '_tour_type', true);
    $difficulty = get_post_meta(get_the_ID(), '_tour_difficulty', true);
    $discount = get_post_meta(get_the_ID(), '_tour_discount_percentage', true);
    $itinerary = get_post_meta(get_the_ID(), '_tour_itinerary', true);
    $includes = get_post_meta(get_the_ID(), '_tour_includes', true);
    $excludes = get_post_meta(get_the_ID(), '_tour_excludes', true);
    $gallery_ids = get_post_meta(get_the_ID(), '_tour_gallery', true);
    
    $current_price = $sale_price ?: $regular_price;
    ?>

    <!-- Tour Detail Header -->
    <section class="tour-detail-header">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo home_url(); ?>">Ana Sayfa</a>
                <i class="fas fa-chevron-right"></i>
                <a href="<?php echo get_post_type_archive_link('tour'); ?>">Turlar</a>
                <i class="fas fa-chevron-right"></i>
                <span><?php the_title(); ?></span>
            </div>
        </div>
    </section>

    <!-- Tour Hero Section -->
    <section class="tour-hero">
        <div class="container">
            <div class="tour-hero-content">
                <div class="tour-hero-header">
                    <div class="tour-title-section">
                        <h1><?php the_title(); ?></h1>
                        <?php if ($location) : ?>
                            <div class="tour-location">
                                <i class="fas fa-map-marker-alt"></i>
                                <span><?php echo esc_html($location); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="tour-price-section">
                        <?php if ($sale_price && $sale_price < $regular_price) : ?>
                            <div class="old-price">$<?php echo number_format($regular_price, 2); ?></div>
                        <?php endif; ?>
                        <div class="current-price">$<?php echo number_format($current_price, 2); ?></div>
                        <div class="price-note">Kişi Başı</div>
                    </div>
                </div>

                <!-- Hero Gallery -->
                <div class="hero-gallery">
                    <div class="main-image">
                        <?php 
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('tour-large');
                        }
                        ?>
                    </div>
                    <?php if ($gallery_ids) : 
                        $ids = explode(',', $gallery_ids);
                        $gallery_images = array_slice($ids, 0, 4);
                        ?>
                        <div class="gallery-thumbs">
                            <?php foreach ($gallery_images as $img_id) : 
                                $image = wp_get_attachment_image_src($img_id, 'tour-thumbnail');
                                if ($image) :
                                ?>
                                <div class="thumb-item">
                                    <img src="<?php echo esc_url($image[0]); ?>" alt="<?php the_title(); ?>">
                                </div>
                            <?php endif; endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Tour Quick Info -->
    <section class="tour-quick-info">
        <div class="container">
            <div class="info-cards">
                <?php if ($duration) : ?>
                    <div class="info-card">
                        <i class="fas fa-clock"></i>
                        <div class="info-content">
                            <h4>Süre</h4>
                            <p><?php echo esc_html($duration); ?> Gün</p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($max_people) : ?>
                    <div class="info-card">
                        <i class="fas fa-users"></i>
                        <div class="info-content">
                            <h4>Maksimum Kişi</h4>
                            <p><?php echo esc_html($max_people); ?> Kişi</p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($min_age) : ?>
                    <div class="info-card">
                        <i class="fas fa-child"></i>
                        <div class="info-content">
                            <h4>Minimum Yaş</h4>
                            <p><?php echo esc_html($min_age); ?>+</p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($tour_type) : ?>
                    <div class="info-card">
                        <i class="fas fa-tag"></i>
                        <div class="info-content">
                            <h4>Tur Tipi</h4>
                            <p><?php echo esc_html(ucfirst($tour_type)); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if ($difficulty) : ?>
                    <div class="info-card">
                        <i class="fas fa-chart-line"></i>
                        <div class="info-content">
                            <h4>Zorluk</h4>
                            <p><?php echo esc_html(ucfirst($difficulty)); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Tabs Navigation -->
    <section class="tour-tabs-section">
        <div class="container">
            <div class="tabs-navigation">
                <button class="tab-btn active" data-tab="overview">Genel Bakış</button>
                <button class="tab-btn" data-tab="itinerary">Program</button>
                <button class="tab-btn" data-tab="includes">Dahil Olanlar</button>
                <button class="tab-btn" data-tab="booking">Rezervasyon</button>
            </div>
        </div>
    </section>

    <!-- Tab Content -->
    <section class="tour-content-section">
        <div class="container">
            <!-- Overview Tab -->
            <div id="overview" class="tab-content active">
                <h2>Genel Bakış</h2>
                <div class="overview-content">
                    <?php the_content(); ?>
                </div>
            </div>

            <!-- Itinerary Tab -->
            <div id="itinerary" class="tab-content">
                <h2>Günlük Program</h2>
                <?php if ($itinerary && is_array($itinerary)) : ?>
                    <div class="itinerary-timeline">
                        <?php foreach ($itinerary as $index => $day) : ?>
                            <div class="itinerary-day">
                                <div class="day-number">
                                    <span>Gün <?php echo $index + 1; ?></span>
                                </div>
                                <div class="day-content">
                                    <h3><?php echo esc_html($day['title']); ?></h3>
                                    <p><?php echo esc_html($day['description']); ?></p>
                                    <?php if (!empty($day['activities'])) : 
                                        $activities = explode("\n", $day['activities']);
                                        ?>
                                        <ul class="activities-list">
                                            <?php foreach ($activities as $activity) : 
                                                if (trim($activity)) :
                                                ?>
                                                <li><i class="fas fa-check"></i> <?php echo esc_html(trim($activity)); ?></li>
                                            <?php endif; endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else : ?>
                    <p>Program bilgisi mevcut değil.</p>
                <?php endif; ?>
            </div>

            <!-- Includes Tab -->
            <div id="includes" class="tab-content">
                <h2>Dahil Olan / Olmayan</h2>
                <div class="includes-grid">
                    <?php if ($includes) : 
                        $includes_array = explode("\n", $includes);
                        ?>
                        <div class="includes-section">
                            <h3><i class="fas fa-check-circle"></i> Dahil Olanlar</h3>
                            <ul class="includes-list">
                                <?php foreach ($includes_array as $item) : 
                                    if (trim($item)) :
                                    ?>
                                    <li><i class="fas fa-check"></i> <?php echo esc_html(trim($item)); ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($excludes) : 
                        $excludes_array = explode("\n", $excludes);
                        ?>
                        <div class="excludes-section">
                            <h3><i class="fas fa-times-circle"></i> Dahil Olmayanlar</h3>
                            <ul class="excludes-list">
                                <?php foreach ($excludes_array as $item) : 
                                    if (trim($item)) :
                                    ?>
                                    <li><i class="fas fa-times"></i> <?php echo esc_html(trim($item)); ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Booking Tab -->
            <div id="booking" class="tab-content">
                <h2>Rezervasyon Yap</h2>
                <div class="booking-form-container">
                    <form id="tour-booking-form" class="booking-form">
                        <input type="hidden" name="tour_id" value="<?php echo get_the_ID(); ?>">
                        <input type="hidden" name="action" value="safwa_reservation_form">
                        <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('safwa_nonce'); ?>">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="booking-name">Ad Soyad *</label>
                                <input type="text" id="booking-name" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="booking-email">E-posta *</label>
                                <input type="email" id="booking-email" name="email" required>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="booking-phone">Telefon *</label>
                                <input type="tel" id="booking-phone" name="phone" required>
                            </div>
                            <div class="form-group">
                                <label for="booking-date">Tur Tarihi *</label>
                                <input type="date" id="booking-date" name="date" required min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="booking-adults">Yetişkin Sayısı *</label>
                                <div class="select-wrapper">
                                    <select id="booking-adults" name="adults" required>
                                        <?php for ($i = 1; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="booking-children">Çocuk Sayısı</label>
                                <div class="select-wrapper">
                                    <select id="booking-children" name="children">
                                        <?php for ($i = 0; $i <= 10; $i++) : ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="special-requests">Özel İstekler</label>
                            <textarea id="special-requests" name="special_requests" rows="4"></textarea>
                        </div>

                        <div class="booking-summary">
                            <div class="summary-row">
                                <span>Kişi Başı Fiyat:</span>
                                <span class="price">$<?php echo number_format($current_price, 2); ?></span>
                            </div>
                            <div class="summary-row total">
                                <span>Toplam:</span>
                                <span class="total-price">$<?php echo number_format($current_price, 2); ?></span>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-calendar-check"></i> Rezervasyon Yap
                        </button>

                        <div class="form-message" style="display: none;"></div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <?php if (comments_open() || get_comments_number()) : ?>
        <section class="reviews-section">
            <div class="container">
                <h2>Yorumlar</h2>
                <?php comments_template(); ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Related Tours -->
    <section class="related-tours">
        <div class="container">
            <h2>Benzer Turlar</h2>
            <div class="tours-grid">
                <?php
                $terms = wp_get_post_terms(get_the_ID(), 'tour_category', array('fields' => 'ids'));
                $related_tours = new WP_Query(array(
                    'post_type' => 'tour',
                    'posts_per_page' => 3,
                    'post__not_in' => array(get_the_ID()),
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'tour_category',
                            'field' => 'term_id',
                            'terms' => $terms,
                        ),
                    ),
                ));
                
                if ($related_tours->have_posts()) :
                    while ($related_tours->have_posts()) : $related_tours->the_post();
                        $reg_price = get_post_meta(get_the_ID(), '_tour_regular_price', true);
                        $s_price = get_post_meta(get_the_ID(), '_tour_sale_price', true);
                        $dur = get_post_meta(get_the_ID(), '_tour_duration', true);
                        $loc = get_post_meta(get_the_ID(), '_tour_location', true);
                        ?>
                        <div class="tour-card">
                            <div class="tour-image">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('tour-thumbnail'); ?>
                                </a>
                            </div>
                            <div class="tour-content">
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <?php if ($loc) : ?>
                                    <div class="tour-location">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <span><?php echo esc_html($loc); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="tour-meta">
                                    <?php if ($dur) : ?>
                                        <span><i class="fas fa-clock"></i> <?php echo esc_html($dur); ?> Gün</span>
                                    <?php endif; ?>
                                </div>
                                <div class="tour-footer">
                                    <div class="tour-price">
                                        <span class="price">$<?php echo number_format($s_price ?: $reg_price, 2); ?></span>
                                    </div>
                                    <a href="<?php the_permalink(); ?>" class="btn btn-primary">Detay</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; wp_reset_postdata(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <script>
    jQuery(document).ready(function($) {
        // Tab switching with scroll to section
        $('.tab-btn').on('click', function() {
            var tab = $(this).data('tab');
            
            $('.tab-btn').removeClass('active');
            $(this).addClass('active');
            
            $('.tab-content').removeClass('active');
            $('#' + tab).addClass('active');
            
            // Scroll to section
            var offset = 135;
            var targetSection = $('#' + tab);
            if (targetSection.length) {
                $('html, body').animate({
                    scrollTop: targetSection.offset().top - offset
                }, 500);
            }
        });

        // Booking form submission
        $('#tour-booking-form').on('submit', function(e) {
            e.preventDefault();
            
            var formData = $(this).serialize();
            var messageDiv = $('.form-message');
            var submitBtn = $(this).find('button[type="submit"]');
            
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Gönderiliyor...');
            
            $.ajax({
                url: safwa_ajax.ajax_url,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        messageDiv.removeClass('error').addClass('success').html(response.data.message).show();
                        $('#tour-booking-form')[0].reset();
                    } else {
                        messageDiv.removeClass('success').addClass('error').html('Bir hata oluştu. Lütfen tekrar deneyin.').show();
                    }
                },
                error: function() {
                    messageDiv.removeClass('success').addClass('error').html('Bağlantı hatası. Lütfen tekrar deneyin.').show();
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-calendar-check"></i> Rezervasyon Yap');
                }
            });
        });

        // Calculate total price
        $('#booking-adults, #booking-children').on('change', function() {
            var adults = parseInt($('#booking-adults').val()) || 1;
            var children = parseInt($('#booking-children').val()) || 0;
            var pricePerPerson = <?php echo $current_price; ?>;
            var total = (adults + children * 0.5) * pricePerPerson;
            
            $('.total-price').text('$' + total.toFixed(2));
        });
    });
    </script>

<?php endwhile; ?>

<?php get_footer(); ?>
