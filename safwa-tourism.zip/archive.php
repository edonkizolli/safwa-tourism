<?php
/**
 * Archive Template (Blog Listing)
 */

get_header(); ?>

<div class="page-header">
    <div class="container">
        <h1><?php 
            if (is_category()) {
                single_cat_title();
            } elseif (is_tag()) {
                single_tag_title();
            } elseif (is_author()) {
                the_author();
            } elseif (is_date()) {
                echo get_the_date('F Y');
            } else {
                echo 'Blog';
            }
        ?></h1>
        <?php if (is_category() && category_description()) : ?>
            <p><?php echo category_description(); ?></p>
        <?php endif; ?>
    </div>
</div>

<section class="blog-archive">
    <div class="container">
        <div class="blog-content-wrapper">
            <div class="blog-main">
                <?php if (have_posts()) : ?>
                    <div class="blog-grid">
                        <?php while (have_posts()) : the_post(); ?>
                            <article class="blog-card">
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="blog-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail('blog-thumbnail'); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="blog-content">
                                    <div class="blog-meta">
                                        <span class="date">
                                            <i class="fas fa-calendar"></i>
                                            <?php echo get_the_date(); ?>
                                        </span>
                                        <span class="author">
                                            <i class="fas fa-user"></i>
                                            <?php the_author(); ?>
                                        </span>
                                        <span class="category">
                                            <i class="fas fa-folder"></i>
                                            <?php the_category(', '); ?>
                                        </span>
                                    </div>
                                    
                                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    
                                    <div class="blog-excerpt">
                                        <?php the_excerpt(); ?>
                                    </div>
                                    
                                    <a href="<?php the_permalink(); ?>" class="read-more">
                                        Devamını Oku <i class="fas fa-arrow-right"></i>
                                    </a>
                                </div>
                            </article>
                        <?php endwhile; ?>
                    </div>

                    <?php
                    the_posts_pagination(array(
                        'mid_size' => 2,
                        'prev_text' => '<i class="fas fa-chevron-left"></i> Önceki',
                        'next_text' => 'Sonraki <i class="fas fa-chevron-right"></i>',
                    ));
                    ?>
                <?php else : ?>
                    <div class="no-posts">
                        <i class="fas fa-search"></i>
                        <p>Yazı bulunamadı.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <aside class="blog-sidebar">
                <!-- Search -->
                <div class="sidebar-widget">
                    <h3>Ara</h3>
                    <form role="search" method="get" class="search-form" action="<?php echo home_url('/'); ?>">
                        <input type="search" class="search-field" placeholder="Ara..." value="<?php echo get_search_query(); ?>" name="s">
                        <button type="submit" class="search-submit"><i class="fas fa-search"></i></button>
                    </form>
                </div>

                <!-- Recent Posts -->
                <div class="sidebar-widget">
                    <h3>Son Yazılar</h3>
                    <ul class="recent-posts">
                        <?php
                        $recent_posts = new WP_Query(array(
                            'posts_per_page' => 5,
                            'post_status' => 'publish'
                        ));
                        
                        if ($recent_posts->have_posts()) :
                            while ($recent_posts->have_posts()) : $recent_posts->the_post();
                                ?>
                                <li>
                                    <?php if (has_post_thumbnail()) : ?>
                                        <div class="recent-post-thumb">
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('thumbnail'); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="recent-post-content">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        <span class="post-date"><?php echo get_the_date(); ?></span>
                                    </div>
                                </li>
                            <?php endwhile; wp_reset_postdata(); ?>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Categories -->
                <div class="sidebar-widget">
                    <h3>Kategoriler</h3>
                    <ul class="category-list">
                        <?php
                        $categories = get_categories(array(
                            'orderby' => 'count',
                            'order' => 'DESC',
                            'hide_empty' => true,
                        ));
                        
                        foreach ($categories as $category) :
                            ?>
                            <li>
                                <a href="<?php echo get_category_link($category->term_id); ?>">
                                    <i class="fas fa-folder"></i>
                                    <?php echo esc_html($category->name); ?>
                                    <span class="count">(<?php echo $category->count; ?>)</span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Tags -->
                <?php
                $tags = get_tags(array('orderby' => 'count', 'order' => 'DESC', 'number' => 20));
                if ($tags) :
                    ?>
                    <div class="sidebar-widget">
                        <h3>Etiketler</h3>
                        <div class="tag-cloud">
                            <?php foreach ($tags as $tag) : ?>
                                <a href="<?php echo get_tag_link($tag->term_id); ?>" class="tag">
                                    <?php echo esc_html($tag->name); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </aside>
        </div>
    </div>
</section>

<?php get_footer(); ?>
