<?php
/**
 * Archive Tour Template (Tours Listing Page)
 */

get_header(); ?>

<div class="page-header">
    <div class="container">
        <h1>Turlarımız</h1>
        <p>Size özel turlarımızı keşfedin</p>
    </div>
</div>

<section class="tours-page">
    <div class="container">
        <!-- Filters -->
        <div class="filters-section">
            <div class="filters-container">
                <!-- Category Filters -->
                <div class="filter-categories">
                    <?php
                    $terms = get_terms(array(
                        'taxonomy' => 'tour_category',
                        'hide_empty' => true,
                    ));
                    
                    $current_term = get_queried_object();
                    ?>
                    <button class="filter-btn <?php echo !is_tax() ? 'active' : ''; ?>" data-category="all">
                        Tümü
                    </button>
                    <?php foreach ($terms as $term) : ?>
                        <button class="filter-btn <?php echo (is_tax() && $current_term->term_id === $term->term_id) ? 'active' : ''; ?>" 
                                data-category="<?php echo esc_attr($term->slug); ?>">
                            <?php echo esc_html($term->name); ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <!-- Search and Sort -->
                <div class="filter-controls">
                    <div class="search-box">
                        <input type="text" id="tour-search" placeholder="Tur ara...">
                        <i class="fas fa-search"></i>
                    </div>

                    <div class="select-wrapper">
                        <select id="sort-by">
                            <option value="date">En Yeni</option>
                            <option value="price-low">Fiyat: Düşük - Yüksek</option>
                            <option value="price-high">Fiyat: Yüksek - Düşük</option>
                            <option value="popular">En Popüler</option>
                        </select>
                    </div>

                    <div class="select-wrapper">
                        <select id="price-range">
                            <option value="">Fiyat Aralığı</option>
                            <option value="0-500">$0 - $500</option>
                            <option value="500-1000">$500 - $1000</option>
                            <option value="1000-2000">$1000 - $2000</option>
                            <option value="2000+">$2000+</option>
                        </select>
                    </div>

                    <div class="select-wrapper">
                        <select id="duration-filter">
                            <option value="">Süre</option>
                            <option value="1-3">1-3 Gün</option>
                            <option value="4-7">4-7 Gün</option>
                            <option value="8-14">8-14 Gün</option>
                            <option value="15+">15+ Gün</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tours Grid -->
        <div class="tours-grid" id="tours-grid">
            <?php
            if (have_posts()) :
                while (have_posts()) : the_post();
                    $regular_price = get_post_meta(get_the_ID(), '_tour_regular_price', true);
                    $sale_price = get_post_meta(get_the_ID(), '_tour_sale_price', true);
                    $duration = get_post_meta(get_the_ID(), '_tour_duration', true);
                    $location = get_post_meta(get_the_ID(), '_tour_location', true);
                    $max_people = get_post_meta(get_the_ID(), '_tour_max_people', true);
                    $badge = get_post_meta(get_the_ID(), '_tour_badge', true);
                    $discount = get_post_meta(get_the_ID(), '_tour_discount_percentage', true);
                    $tour_type = get_post_meta(get_the_ID(), '_tour_type', true);
                    ?>
                    <div class="tour-card" 
                         data-price="<?php echo esc_attr($sale_price ?: $regular_price); ?>"
                         data-duration="<?php echo esc_attr($duration); ?>"
                         data-type="<?php echo esc_attr($tour_type); ?>">
                        <?php if ($badge) : ?>
                            <span class="badge"><?php echo esc_html(ucfirst($badge)); ?></span>
                        <?php endif; ?>
                        <?php if ($discount) : ?>
                            <span class="discount">%<?php echo esc_html($discount); ?> İndirim</span>
                        <?php endif; ?>
                        
                        <div class="tour-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php 
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('tour-thumbnail');
                                } else {
                                    echo '<img src="' . get_template_directory_uri() . '/assets/images/default-tour.jpg" alt="' . get_the_title() . '">';
                                }
                                ?>
                            </a>
                            <div class="tour-quick-info">
                                <?php if ($duration) : ?>
                                    <span><i class="fas fa-clock"></i> <?php echo esc_html($duration); ?> Gün</span>
                                <?php endif; ?>
                                <?php if ($max_people) : ?>
                                    <span><i class="fas fa-users"></i> <?php echo esc_html($max_people); ?> Kişi</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="tour-content">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            
                            <?php if ($location) : ?>
                                <div class="tour-location">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?php echo esc_html($location); ?></span>
                                </div>
                            <?php endif; ?>

                            <div class="tour-excerpt">
                                <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
                            </div>

                            <div class="tour-footer">
                                <div class="tour-price">
                                    <?php if ($sale_price && $sale_price < $regular_price) : ?>
                                        <span class="old-price">$<?php echo esc_html(number_format($regular_price, 2)); ?></span>
                                        <span class="price">$<?php echo esc_html(number_format($sale_price, 2)); ?></span>
                                    <?php else : ?>
                                        <span class="price">$<?php echo esc_html(number_format($regular_price, 2)); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="btn btn-primary">Detaylar</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <div class="no-tours">
                    <i class="fas fa-search"></i>
                    <p>Aradığınız kriterlerde tur bulunamadı.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php
        the_posts_pagination(array(
            'mid_size' => 2,
            'prev_text' => '<i class="fas fa-chevron-left"></i>',
            'next_text' => '<i class="fas fa-chevron-right"></i>',
        ));
        ?>
    </div>
</section>

<!-- Add Tour Filtering JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tourCards = document.querySelectorAll('.tour-card');
    const searchInput = document.getElementById('tour-search');
    const sortSelect = document.getElementById('sort-by');
    const priceSelect = document.getElementById('price-range');
    const durationSelect = document.getElementById('duration-filter');
    const categoryBtns = document.querySelectorAll('.filter-btn');

    // Filter function
    function filterTours() {
        const searchTerm = searchInput.value.toLowerCase();
        const priceRange = priceSelect.value;
        const durationRange = durationSelect.value;

        tourCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const excerpt = card.querySelector('.tour-excerpt').textContent.toLowerCase();
            const price = parseFloat(card.dataset.price);
            const duration = parseFloat(card.dataset.duration);

            let show = true;

            // Search filter
            if (searchTerm && !title.includes(searchTerm) && !excerpt.includes(searchTerm)) {
                show = false;
            }

            // Price filter
            if (priceRange) {
                const [min, max] = priceRange.split('-').map(p => p.replace('+', ''));
                if (max) {
                    if (price < parseFloat(min) || price > parseFloat(max)) show = false;
                } else {
                    if (price < parseFloat(min)) show = false;
                }
            }

            // Duration filter
            if (durationRange) {
                const [min, max] = durationRange.split('-').map(d => d.replace('+', ''));
                if (max) {
                    if (duration < parseFloat(min) || duration > parseFloat(max)) show = false;
                } else {
                    if (duration < parseFloat(min)) show = false;
                }
            }

            card.style.display = show ? 'block' : 'none';
        });
    }

    // Sort function
    function sortTours() {
        const sortBy = sortSelect.value;
        const toursGrid = document.getElementById('tours-grid');
        const cardsArray = Array.from(tourCards);

        cardsArray.sort((a, b) => {
            const priceA = parseFloat(a.dataset.price);
            const priceB = parseFloat(b.dataset.price);

            switch(sortBy) {
                case 'price-low':
                    return priceA - priceB;
                case 'price-high':
                    return priceB - priceA;
                case 'popular':
                    return a.querySelector('.badge') ? -1 : 1;
                default:
                    return 0;
            }
        });

        cardsArray.forEach(card => toursGrid.appendChild(card));
    }

    // Event listeners
    searchInput.addEventListener('input', filterTours);
    priceSelect.addEventListener('change', filterTours);
    durationSelect.addEventListener('change', filterTours);
    sortSelect.addEventListener('change', sortTours);

    categoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            categoryBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.dataset.category;
            if (category === 'all') {
                window.location.href = '<?php echo get_post_type_archive_link('tour'); ?>';
            } else {
                window.location.href = '<?php echo home_url('/tour-category/'); ?>' + category;
            }
        });
    });
});
</script>

<?php get_footer(); ?>
