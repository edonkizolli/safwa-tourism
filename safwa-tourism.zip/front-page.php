<?php
/**
 * Front Page Template (Home Page)
 */

get_header(); ?>

<!-- Hero Slider -->
<section class="hero-slider">
    <div class="slider-container">
        <?php
        $banners = new WP_Query(array(
            'post_type' => 'banner',
            'posts_per_page' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC'
        ));
        
        if ($banners->have_posts()) :
            while ($banners->have_posts()) : $banners->the_post();
                $subtitle = get_post_meta(get_the_ID(), '_banner_subtitle', true);
                $button_text = get_post_meta(get_the_ID(), '_banner_button_text', true);
                $button_link = get_post_meta(get_the_ID(), '_banner_button_link', true);
                $features = get_post_meta(get_the_ID(), '_banner_features', true);
                ?>
                <div class="slide">
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="slide-image">
                            <?php the_post_thumbnail('full'); ?>
                        </div>
                    <?php endif; ?>
                    <div class="container">
                        <div class="slide-content">
                            <?php if ($subtitle) : ?>
                                <p class="subtitle"><?php echo esc_html($subtitle); ?></p>
                            <?php endif; ?>
                            <h1><?php the_title(); ?></h1>
                            <?php if (get_the_content()) : ?>
                                <p class="description"><?php echo wp_kses_post(get_the_content()); ?></p>
                            <?php endif; ?>
                            <?php if ($features) : 
                                $features_array = explode("\n", $features);
                                ?>
                                <div class="features">
                                    <?php foreach ($features_array as $feature) : 
                                        $parts = explode(' ', trim($feature), 3);
                                        if (count($parts) >= 3) :
                                            ?>
                                            <div class="feature-item">
                                                <i class="<?php echo esc_attr($parts[0] . ' ' . $parts[1]); ?>"></i>
                                                <span><?php echo esc_html($parts[2]); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($button_text && $button_link) : ?>
                                <a href="<?php echo esc_url($button_link); ?>" class="btn btn-primary"><?php echo esc_html($button_text); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        <?php endif; ?>
    </div>
    <button class="slider-btn prev" id="prev-slide"><i class="fas fa-chevron-left"></i></button>
    <button class="slider-btn next" id="next-slide"><i class="fas fa-chevron-right"></i></button>
    <div class="slider-dots" id="slider-dots"></div>
</section>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-star"></i>
                </div>
                <h3>Premium Hizmet</h3>
                <p>En kaliteli turizm deneyimi</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-users"></i>
                </div>
                <h3>Profesyonel Rehberler</h3>
                <p>Uzman rehberlerimizle güvenli seyahat</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-hotel"></i>
                </div>
                <h3>5 Yıldızlı Oteller</h3>
                <p>Konforlu konaklama garantisi</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <h3>Lezzetli Yemekler</h3>
                <p>Her öğünde özel menüler</p>
            </div>
        </div>
    </div>
</section>

<!-- Popular Tours -->
<section class="tours-section">
    <div class="container">
        <div class="section-header">
            <h2>Popüler Turlar</h2>
            <p>En çok tercih edilen turlarımızı keşfedin</p>
        </div>

        <div class="tours-grid">
            <?php
            $popular_tours = new WP_Query(array(
                'post_type' => 'tour',
                'posts_per_page' => 6,
                'meta_key' => '_tour_badge',
                'meta_value' => 'popular'
            ));
            
            if ($popular_tours->have_posts()) :
                while ($popular_tours->have_posts()) : $popular_tours->the_post();
                    $regular_price = get_post_meta(get_the_ID(), '_tour_regular_price', true);
                    $sale_price = get_post_meta(get_the_ID(), '_tour_sale_price', true);
                    $duration = get_post_meta(get_the_ID(), '_tour_duration', true);
                    $location = get_post_meta(get_the_ID(), '_tour_location', true);
                    $badge = get_post_meta(get_the_ID(), '_tour_badge', true);
                    $discount = get_post_meta(get_the_ID(), '_tour_discount_percentage', true);
                    ?>
                    <div class="tour-card">
                        <?php if ($badge) : ?>
                            <span class="badge"><?php echo esc_html(ucfirst($badge)); ?></span>
                        <?php endif; ?>
                        <?php if ($discount) : ?>
                            <span class="discount">%<?php echo esc_html($discount); ?> İndirim</span>
                        <?php endif; ?>
                        <div class="tour-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php 
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('tour-thumbnail');
                                }
                                ?>
                            </a>
                        </div>
                        <div class="tour-content">
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <?php if ($location) : ?>
                                <div class="tour-location">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span><?php echo esc_html($location); ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="tour-meta">
                                <?php if ($duration) : ?>
                                    <span><i class="fas fa-clock"></i> <?php echo esc_html($duration); ?> Gün</span>
                                <?php endif; ?>
                            </div>
                            <div class="tour-footer">
                                <div class="tour-price">
                                    <?php if ($sale_price) : ?>
                                        <span class="old-price">$<?php echo esc_html($regular_price); ?></span>
                                        <span class="price">$<?php echo esc_html($sale_price); ?></span>
                                    <?php else : ?>
                                        <span class="price">$<?php echo esc_html($regular_price); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="btn btn-primary">Detay</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            <?php endif; ?>
        </div>

        <div class="section-footer">
            <a href="<?php echo get_post_type_archive_link('tour'); ?>" class="btn btn-outline">Tüm Turlar</a>
        </div>
    </div>
</section>

<!-- Latest Blog Posts -->
<section class="blog-section">
    <div class="container">
        <div class="section-header">
            <h2>Blog</h2>
            <p>Son yazılarımızı okuyun</p>
        </div>

        <div class="blog-grid">
            <?php
            $latest_posts = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 3
            ));
            
            if ($latest_posts->have_posts()) :
                while ($latest_posts->have_posts()) : $latest_posts->the_post();
                    ?>
                    <article class="blog-card">
                        <div class="blog-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php 
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('blog-thumbnail');
                                }
                                ?>
                            </a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <span><i class="fas fa-calendar"></i> <?php echo get_the_date(); ?></span>
                                <span><i class="fas fa-user"></i> <?php the_author(); ?></span>
                            </div>
                            <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <?php the_excerpt(); ?>
                            <a href="<?php the_permalink(); ?>" class="read-more">Devamını Oku <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata(); ?>
            <?php endif; ?>
        </div>

        <div class="section-footer">
            <a href="<?php echo get_permalink(get_option('page_for_posts')); ?>" class="btn btn-outline">Tüm Yazılar</a>
        </div>
    </div>
</section>

<?php get_footer(); ?>
