<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Safwa Turizm</h3>
                <p>Unutulmaz seyahat deneyimleri için profesyonel turizm çözümleri sunuyoruz.</p>
                <div class="social-links">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                    <a href="#" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>

            <div class="footer-section">
                <h4>Hızlı Linkler</h4>
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'container' => false,
                    'menu_class' => 'footer-links',
                    'fallback_cb' => 'safwa_default_footer_menu'
                ));
                ?>
            </div>

            <div class="footer-section">
                <h4>Popüler Turlar</h4>
                <ul class="footer-links">
                    <?php
                    $popular_tours = new WP_Query(array(
                        'post_type' => 'tour',
                        'posts_per_page' => 5,
                        'meta_key' => '_tour_badge',
                        'meta_value' => 'popular'
                    ));
                    
                    if ($popular_tours->have_posts()) {
                        while ($popular_tours->have_posts()) {
                            $popular_tours->the_post();
                            echo '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </ul>
            </div>

            <div class="footer-section">
                <h4>İletişim</h4>
                <ul class="footer-links">
                    <li><i class="fas fa-map-marker-alt"></i> İstanbul, Türkiye</li>
                    <li><i class="fas fa-phone"></i> +90 555 123 45 67</li>
                    <li><i class="fas fa-envelope"></i> info@safwaturizm.com</li>
                    <li><i class="fas fa-clock"></i> Pzt-Cum: 09:00 - 18:00</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Tüm hakları saklıdır.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
